<?php $__env->startSection('content'); ?>
<?php echo e($storeId=Auth::user()->store->id); ?>

<div class="container">
    <div class="row">
        <div class="col-lg-6">
    <img src="<?php echo e(asset('assets/RegistroComercio2.svg')); ?>" alt="imgRegistro" id="imgRegistroComercio2">
        </div>

        <div class="col-lg-6">
            <section id="RegistroComercio">

        <h1>Paso 2</h1>
        <p>Al registrar tu comercio los vecinos podrán elegirte para comprar regalos a nuestros héroes. </p>
        
        <form  method="POST" action=" <?php echo e(route('stores.updateRegister', $storeId)); ?>"
            enctype="multipart/form-data">
          <?php echo e(method_field('put')); ?>

          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="inputNombreComercio">Nombre del comercio</label>
            <input type="text" id="inputNombrecomercio" placeholder=""
            class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
             required autocomplete="name" autofocus>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group ">
            <label for="inputDireccion">Dirección del comercio</label>


            <input type="text" id="inputDireccion" placeholder="Donde está tu local?"
                   class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address"
                   required autocomplete="address">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="inputCategoria" id="Category">Categorías</label>
            <select class="form-control" id="inputCategoria" name='category'
                    >
                <option >Cafetería</option>
                <option >Cervecería</option>
                <option >Pizzería</option>
                <option >Farmacia</option>
                <option >Kiosco</option>
                <option >Otro</option>
            </select>
        </div>

        <div class="form-group">
            <label for="inputTel">Teléfono de contacto</label>
            <input type="text" id="inputTel" placeholder=""
                   class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone"
                    required autocomplete="phone">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <p id="tycRegistroComercio">Al hacer click en "Registrar mi comercio" declarás que toda la información ingresada es real y tenés la capacidad para actuar en representacion del negocio.  </p>
        <button type="submit" class="btn btn-principal btn-block" id="btnRegistroComercio1">Registrar mi
            comercio</button>
        </form>

            </section>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/auth/registerStore2.blade.php ENDPATH**/ ?>