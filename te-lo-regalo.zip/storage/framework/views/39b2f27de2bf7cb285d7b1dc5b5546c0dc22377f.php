<?php $__env->startSection('content'); ?>
    <?php $storeInfo = Auth::user()->store ?>
    <?php $userInfo = Auth::user()?>
    <div class='container'>
        <div id="menuMisProductos">
            <ul class="nav flex-lg-column justify-content-center nav-pills " id="myTab" role="tablist">
                <li><a class="nav-item" id="nav-perfil-tab" href="<?php echo e(route('stores.miPerfil')); ?>"
                       aria-controls="nav-perfil" aria-selected="false">Perfil</a></li>
                <li><a class="nav-item active" id="nav-ventas-tab" href="<?php echo e(route('stores.misVentas')); ?>"
                       aria-controls="nav-ventas" aria-selected="true">Ventas</a></li>
                <li><a class="nav-item " id="nav-productos-tab" href="<?php echo e(route('stores.misProductos')); ?>"
                       aria-controls="nav-productos" aria-selected="false">Productos</a></li>
            </ul>
        </div>
        <h1 class="tituloPerfilCom">Perfil</h1>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
             aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Elige una foto de perfil..</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="row" method="POST" action=" <?php echo e(route('stores.updateImage', $storeInfo->id)); ?>"
                          enctype="multipart/form-data">

                        <?php echo e(method_field('put')); ?>

                        <?php echo e(csrf_field()); ?>


                        <div class="modal-body">
                            <input id="file-input" name="avatar" type="file"/>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="input" class="btn btn-primary">Guardar</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
        <form class="row" method="POST" action=" <?php echo e(route('stores.update', $storeInfo->id)); ?>"
              enctype="multipart/form-data">
            <?php echo e(method_field('put')); ?>

            <?php echo e(csrf_field()); ?>

            <div class="col-md-auto mb-5">
                <div class="logoPerfil">
                    <div class="image-upload d-flex flex-row-reverse " data-toggle="modal" data-target="#exampleModal">
                        <span class="far fa-edit "></span>
                    </div>
                    <?php if($storeInfo->avatar): ?>
                        <img src="<?php echo e(Storage::url($storeInfo->avatar)); ?>" alt="FotoHeroe">
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/camera_ 1.svg')); ?>" alt="FotoHeroe">
                    <?php endif; ?>
                </div>
            </div>

            <div class="col text-center mt-3 mb-5">
                <h4>La Url de tu negocio es:</h4>
                <p>https://www.figma.com/file/8mOR2VUQF08JLjzeHQBfC2/</p>
                <button class="btn btn-principal">Compartir</button>
            </div>

            <div class="col-lg-6">

                <section>
                    <?php if(session()->get('success')): ?>


                        <div class="alert alert-warning alert-dismissible fade show" role="alert">

                            <strong><?php echo e(session()->get('success')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                    <?php endif; ?>
                    <div class="form-group ">
                        <label for="inputNombrecomercio">Nombre del comercio</label>
                        <input type="text" id="inputNombrecomercio" placeholder=""
                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                               value="<?php echo e($storeInfo->name); ?>" required autocomplete="name" autofocus>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="inputEmail">Email</label>
                        <input type="email" class="form-control" id="inputEmail" readonly
                               value="<?php echo e($userInfo->email); ?>">
                    </div>
                    <div class="form-group">
                        <label for="inputPass">Contraseña</label>

                        <input type="password" class="form-control" id="inputPass" placeholder="">
                    </div>


                </section>
            </div>

            <div class="col-lg-6">
                <section>

                    <div class="form-group ">
                        <label for="inputDireccion">Dirección del comercio</label>


                        <input type="text" id="inputDireccion" placeholder="Donde está tu local?"
                               class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address"
                               value="<?php echo e($storeInfo->address); ?>" required autocomplete="address">
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="inputNombreApellido">Tu nombre y apellido</label>
                        <input type="text" class="form-control" id="inputNombreApellido" placeholder=""
                               value="<?php echo e($userInfo->name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="inputTel">Teléfono de contacto</label>
                        <input type="text" id="inputTel" placeholder=""
                               class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone"
                               value="<?php echo e($storeInfo->phone); ?>" required autocomplete="phone">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                </section>

            </div>

            <div class="col-12 mb-3 mt-3">
                <hr class="solid">
            </div>

            <div class="col-lg-6">
                <section>

                    <div class="form-group">
                        <label for="inputCategoria" id="Category">Categorías</label>
                        <select class="form-control" id="inputCategoria" name='category'
                                selected="<?php echo e($storeInfo->category); ?>">
                            <option <?php echo e(($storeInfo->category == 'Cafetería') ? "selected" : ""); ?>>Cafetería</option>
                            <option <?php echo e(($storeInfo->category == 'Cervecería') ? "selected" : ""); ?>>Cervecería</option>
                            <option <?php echo e(($storeInfo->category == 'Pizzería') ? "selected" : ""); ?>>Pizzería</option>
                            <option <?php echo e(($storeInfo->category == 'Farmacia') ? "selected" : ""); ?>>Farmacia</option>
                            <option <?php echo e(($storeInfo->category == 'Kiosco') ? "selected" : ""); ?>>Kiosco</option>
                            <option <?php echo e(($storeInfo->category == 'Otro') ? "selected" : ""); ?>>Otro</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="inputDesc">Descripción</label>
                        <textarea type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  name="description" required autocomplete="description" id="inputDesc" rows="3"><?php echo e($storeInfo->description); ?>

                        </textarea>
                    </div>
                </section>
            </div>

            <div class="col-lg-6">
                <section>
                    <div class="form-group">
                        <label for="inputFace">Link perfil de Facebook</label>
                        <input type="text" name="facebook" class="form-control" id="inputFace"
                               value="<?php echo e($storeInfo->facebook); ?>">

                    </div>
                    <div class="form-group">
                        <label for="inputInsta">Link perfil de Instagram</label>
                        <input type="text" name="instagram" class="form-control" id="inputInsta"
                               value="<?php echo e($storeInfo->instagram); ?>">
                    </div>

                    <div class="form-group">
                        <label for="inputHorario">Horarios</label>
                        <input type="text" class="form-control" name="horarios" id="inputHorario"
                               value="<?php echo e($storeInfo->horarios); ?>">
                    </div>

                    <a class="btn btn-alternative btn-block"
                       href="https://auth.mercadopago.com.ar/authorization?client_id=5661899751765285&response_type=code&platform_id=mp&redirect_uri=http%3A%2F%2Flocalhost:8000/procesar-pago">
                        Vincular mi cuenta de mercado pago
                    </a>
                </section>
            </div>

            <div class="col-lg-12 mt-5">
                <div class="row">
                    <div class="col-4">
                        <button class="btn btn-alternative btn-block">Cancelar</button>
                    </div>
                    <div class="col-8">
                        <button type="submit" class="btn btn-principal btn-block mb-5">Guardar cambios</button>
                    </div>
                </div>
            </div>

        </form>


    </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/stores/miPerfil.blade.php ENDPATH**/ ?>