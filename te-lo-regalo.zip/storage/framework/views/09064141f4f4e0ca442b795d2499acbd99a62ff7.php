<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Editar Mi Comercio</h1>
    <form action=" <?php echo e(route('stores.update', $store->id)); ?>" method="POST">
    <?php echo e(method_field('PATCH')); ?>

    <?php echo e(csrf_field()); ?>

        <input type="hidden" name="_method" value="PATCH">
        <label for="name"><?php echo e('name'); ?></label>
        <input type="text" name="name" id="name" value="<?php echo e($store->name); ?>">

        <input type="submit" value="Editar">
        <a href="<?php echo e(url('/stores')); ?>">Cancelar</a>
    </form>
</body>
</html><?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/stores/edit.blade.php ENDPATH**/ ?>