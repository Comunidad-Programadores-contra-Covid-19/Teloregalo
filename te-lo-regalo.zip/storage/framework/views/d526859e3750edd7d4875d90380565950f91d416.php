<?php $__env->startSection('content'); ?>

<!-- Inicio contenedor -->
<div class="container">
    <!-- Inicio Botón "volver" -->
    <div class="volver">
        <a href="<?php echo e(url()->previous()); ?>"><  Volver</a>
    </div>
        <!-- Fin Botón "volver" -->
    <div class="row ">
        <div class="col-md-auto">
            <?php if($store->avatar): ?>
            <img src="<?php echo e(Storage::url($store->avatar)); ?>" alt="" class="card-image-profile">
            <?php else: ?>
            <img src="https://via.placeholder.com/150" alt="" class="card-image-profile">
            <?php endif; ?>
           
        </div>
        <div class="col">
            <div class="card-description-profile">
             
                
                <h3><?php echo e($store->name); ?></h3>
                <div id="card-reputation">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star"></span>
                    <span class="fa fa-star"></span>
                </div>
                <p><span><i class="fas fa-map-marker-alt"></i></span><?php echo e($store->address); ?></p>
                <p><span><i class="fas fa-clock"></i></span><?php echo e($store->horarios); ?></p>
                <h6>Descripcion</h6>
                <p><?php echo e($store->description); ?></p>
            </div>
        </div>
    </div>
  
    <?php if(Session::has('info')): ?>
        <div class="alert alert-info">
            <button type="button" class="close" data-dismiss="alert">
                &times;
            </button>
            <?php echo e(Session::get('info')); ?>

        </div>
    <?php endif; ?>
    
    <hr class="solid">
    <div class="row">
        <?php
        // SDK de Mercado Pago
        require '../vendor/autoload.php'; 
        // Agrega credenciales
         \MercadoPago\SDK::setAccessToken($credentials->access_token);  
    /*   \MercadoPago\SDK::setAccessToken('TEST-5841017781823689-050723-4081492e6e230f3f7078e56332de7955-318863690');  */
     
        ?>
        <?php $__currentLoopData = $store->offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
        $preference = new MercadoPago\Preference();
   


     
        $item = new MercadoPago\Item();
        $item->id =$offer->id; 
        $item->title = $offer->name_offer ;
        $item->description =$offer->description_offer ;
        $item->quantity = 1;
        $item->unit_price = $offer->cost;
        $item->category_id =$offer->id;
        $preference->back_urls = array(
        "success" => "https://www.tu-sitio/success",
        "failure" => "http://www.tu-sitio/failure",
        "pending" => "http://www.tu-sitio/pending"
    );
        $preference->items = array($item);
    
        $preference->save(); 


        ?>
        <div class="col-xs-12 col-md-6 col-xl-4">
            <div class="card-product">
                <div class="row">
                    <div class="col-6">
                        <img src="https://via.placeholder.com/150" alt="" class="card-image-product ">
                    </div>
                    <div class="col-6">
                        <div class=" card-index-product" >
                            <div>
                                <p>Total vendidos</p>
                                <p><b><?php echo e($offer->total_amount); ?></b></p>
                                <hr class="solid">
                                <p>Disponibles </p>
                                <p><b><?php echo e($offer->amount); ?></b></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-description-product">
                    <h4><?php echo e($offer->name_offer); ?></h4>
                    <p><?php echo e($offer->description_offer); ?></p>
                    <h3>$ <?php echo e($offer->cost); ?></h3>
                    
                </div>
                <div class="card-btn-product ">
                 <form action="<?php echo e(route('verificar.pago')); ?>" method="POST"> 
                    <input type="hidden" name="ofert" value="TEST-5841017781823689-050723-4081492e6e230f3f7078e56332de7955-318863690">
                    <?php echo csrf_field(); ?>
                        
                        <script 
                        data-button-label="Comprar"
                        src="https://www.mercadopago.com.ar/integrations/v1/web-payment-checkout.js"
                        data-preference-id="<?php echo $preference->id;?>">
                      
                        </script>
                     
                  </form> 
                    <?php if(!Auth::guest()): ?>
                        <?php if(Auth::user()->rol == 'client'): ?>
                            <a class="btn-alternative btn-block" href="<?php echo e(route('otps.create', ['idstore' => $store->id, 'idclient' => Auth::user()->id,'idOffer'=>$offer->id])); ?>">Retirar</a>   
                        <?php endif; ?>
                    <?php endif; ?>
                  
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<!-- Fin contenedor -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/stores/index_profile.blade.php ENDPATH**/ ?>