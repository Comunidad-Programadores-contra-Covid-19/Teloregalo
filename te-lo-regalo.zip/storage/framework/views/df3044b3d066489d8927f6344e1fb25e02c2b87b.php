<?php $user=Auth::user()->store ?>

<?php $__env->startSection('content'); ?>
<body>

    <div class="container">
        <div class="row">
            <img src="https://lifeatbrio.com/wp-content/uploads/2016/11/user-placeholder.jpg" class="rounded mx-auto m-4 d-block col-2" >
        </div>

    <div>
      <?php if(Session::has('info')): ?>
        <div class="alert alert-info">
            <button type="button" class="close" data-dismiss="alert">
                &times;
            </button>
            <?php echo e(Session::get('info')); ?>

        </div>
      <?php endif; ?>
    </div>
    
    </div>
    <nav class="container">
        <div class="nav nav-tabs row" id="nav-tab" role="tablist">
          <a class="nav-item nav-link active col-4" id="nav-perfil-tab" data-toggle="tab" href="#nav-perfil" role="tab" aria-controls="nav-perfil" aria-selected="true">Perfil</a>
          <a class="nav-item nav-link col-4" id="nav-regalos-tab" data-toggle="tab" href="#nav-regalos" role="tab" aria-controls="nav-regalos" aria-selected="false">Regalos</a>
          <a class="nav-item nav-link col-4" id="nav-catalogo-tab" data-toggle="tab" href="#nav-catalogo" role="tab" aria-controls="nav-catalogo" aria-selected="false">Catalogos</a>
        </div>
      </nav>
      <div class="tab-content" id="nav-tabContent">
        <div class="tab-pane fade show active" id="nav-perfil" role="tabpanel" aria-labelledby="nav-perfil-tab">
            <?php echo $__env->make('stores.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('profile'); ?>
        </div>
        <div class="tab-pane fade" id="nav-regalos" role="tabpanel" aria-labelledby="nav-regalos-tab">
            <?php echo $__env->make('stores.gifts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('gifts'); ?>
        </div>
        <div class="tab-pane fade" id="nav-catalogo" role="tabpanel" aria-labelledby="nav-catalogo-tab">
            <?php echo $__env->make('stores.catalogue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('catalogue'); ?>
        </div>
      </div>

      <ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" href="#">Perfil</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Regalos</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="/offers">Catalogo</a>
  </li>
</ul>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/stores/index.blade.php ENDPATH**/ ?>