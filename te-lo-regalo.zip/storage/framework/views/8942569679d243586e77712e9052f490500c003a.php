<?php $__env->startSection('content'); ?>
<?php /* $storeOffers=Auth::user()->store->offers;  */

   
?>
<div class="container">
<div id="menuMisProductos">
    <ul class="nav flex-lg-column justify-content-center nav-pills " id="myTab" role="tablist">
        <li ><a class="nav-item" id="nav-perfil-tab"    href="<?php echo e(route('stores.miPerfil')); ?>"  aria-controls="nav-perfil" aria-selected="false">Perfil</a></li>
        <li ><a class="nav-item active" id="nav-ventas-tab" href="<?php echo e(route('stores.misVentas')); ?>"  aria-controls="nav-ventas" aria-selected="true">Ventas</a></li>
        <li><a class="nav-item " id="nav-productos-tab"  href="<?php echo e(route('stores.misProductos')); ?>"  aria-controls="nav-productos" aria-selected="false">Productos</a></li>
    </ul>
</div>
<div id="formProductos">
    <div id="imgAgregarProd">
        <img src="<?php echo e(asset('assets/camera_ 1.svg')); ?>" alt="producto">
    </div>
    

    <form class="col-md-12 col-lg-12" method="POST" action="/offers">
        <?php echo csrf_field(); ?>
        <div class="form-group ">
            <label for="inputTitulo">Título</label>
               <input type="text" name="name_offer" placeholder="Nombre" required class="form-control mb-2"/>
        </div>
        <div class="form-group">
            <label for="exampleFormControlTextarea1">Descripción</label>
            
      
            <textarea name="description_offer" placeholder="Descripción" required class="form-control mb-2" id="exampleFormControlTextarea1" rows="3" ></textarea>
        </div>
        <div class="form-group">
            <label for="inputPrecio">Precio</label>
            <input
            type="text"
            name="cost"
            placeholder="Precio"
            class="form-control mb-2" id="inputPrecio" required/>
     
        </div>
        <button type="submit" class="btn btn-principal btn-block" style="font-weight: bold;" id="btnAgregarProducto">Agregar producto</button>
    </form>
</div>
<!-- Fin Formulario Agregar Producto -->

<!-- Inicio Productos del comercio -->
<section id="misProductos">

    <h1>Productos</h1>

    <div id="tarjetasMisProductos">
        <?php if(session()->get('success')): ?>
 
      
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            
            <strong><?php echo e(session()->get('success')); ?></strong> 
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
    
    <?php endif; ?>
    <?php $__currentLoopData = $storeOffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="tarjProducto">
            <img src="<?php echo e(asset('assets/logo%20regalo.svg')); ?>" alt="producto">
            <form action="<?php echo e(route('offers.destroy', $offers->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input src="<?php echo e(asset('assets/borrar.svg')); ?>" type="image" alt="borrar" title="Eliminar" id="eliminar">
            </form>
       
            <p id="nombreProducto"><?php echo e($offers->name_offer); ?></p>
            <p id="descrProducto"><?php echo e($offers->description_offer); ?></p>
            <p id="precioProd">$ <?php echo e($offers->cost); ?></p>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/stores/misProductos.blade.php ENDPATH**/ ?>