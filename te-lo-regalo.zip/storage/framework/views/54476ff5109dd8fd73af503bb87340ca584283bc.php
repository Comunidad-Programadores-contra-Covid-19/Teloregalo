<?php $__env->startSection('content'); ?>
    
    <div class="container">
    
        <div class="row justify-content-center">
    
            <div class="col-md-8">
            <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Agregar oferta</span>
                <a href="/offers" class="btn btn-primary btn-sm">Volver a lista de ofertas</a>
            </div>
            
            <div class="card-body">
                
            <form method="POST" action="/offers">
                <?php echo csrf_field(); ?>
                <input
                type="text"
                name="name_offer"
                placeholder="Nombre"
                class="form-control mb-2"/>

                <input
                type="text"
                name="description_offer"
                placeholder="Descripción"
                class="form-control mb-2"/>

                <input
                type="text"
                name="cost"
                placeholder="Precio"
                class="form-control mb-2"/>

                <input
                type="number"
                name="amount"
                placeholder="Cantidad"
                class="form-control mb-2"/>

                Habilitar<input
                type="checkbox"
                id="is_enabled"
                class="form-control mb-2"/>

                <button class="btn btn-primary btn-block"
                type="submit">Agregar</button>
                </form>
            </div>

            </div>
            
            </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/offers/create.blade.php ENDPATH**/ ?>