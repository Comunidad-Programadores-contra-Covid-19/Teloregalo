<?php $__env->startSection('content'); ?>

<div class="container">
        <div class="row">
            <img src="https://lifeatbrio.com/wp-content/uploads/2016/11/user-placeholder.jpg" class="rounded mx-auto m-4 d-block col-2" >
        </div>

        <div class="nav nav-tabs row">
    <a class="nav-item nav-link col-4" href="#">Perfil</a>
    <a class="nav-link col-4" href="#">Regalos</a>
    <a class="nav-link active col-4" href="/offers">Catalogo</a>
</div>

    <div class="row justify-content-center">

        <div class="col-md-8">
            <?php if(session()->get('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span>Lista de Ofertas de <?php echo e(auth()->user()->name); ?> </span>
                    <a href="/offers/create" class="btn btn-primary btn-sm">Nueva Oferta</a>
                </div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Id</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Descripción</th>
                                <th scope="col">Precio</th>
                                <th scope="col">Cantidad</th>
                                <th scope="col">Habilitado</th>
                                <th scope="col"></td>
                                <th scope="col"></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($item->id); ?></th>
                                <td><?php echo e($item->name_offer); ?></td>
                                <td><?php echo e($item->description_offer); ?></td>
                                <td><?php echo e($item->cost); ?></td>
                                <td><?php echo e($item->amount); ?></td>
                                <td><?php echo e($item->is_enabled); ?></td>
                                <td><a href="<?php echo e(route('offers.edit',$item->id)); ?>" class="btn btn-primary btn-sm">Editar</a></td>
                                <td>
                                <form action="<?php echo e(route('offers.destroy', $item->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                                </form></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php echo e($offers->links()); ?>

                </div>

            </div>

        </div>
    </div>







</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/offers/list.blade.php ENDPATH**/ ?>