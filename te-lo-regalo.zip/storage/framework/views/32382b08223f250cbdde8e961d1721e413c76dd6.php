<?php $__env->startSection('catalogue'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>
                SOY EL CATALOGO
      
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/stores/catalogue.blade.php ENDPATH**/ ?>