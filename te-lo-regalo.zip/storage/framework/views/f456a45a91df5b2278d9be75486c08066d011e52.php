<?php $__env->startSection('gifts'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>
                
                <form action="<?php echo e(route('otps.destroy', Auth::user()->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <input type="text" name="codigo">
                    <button class="btn btn-link" type="submit">Entregar</button>

                </form>
      
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/stores/gifts.blade.php ENDPATH**/ ?>