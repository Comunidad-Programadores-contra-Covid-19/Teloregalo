<?php   /* $user=Auth::user()->client */  ?>

<?php $__env->startSection('content'); ?>
<body>
    <!-- Inicio contenedor -->
    <div class="container">
      
        <!-- Inicio Botón "volver" -->
        <div class="volver">
            <button href="<?php echo e(redirect()->getUrlGenerator()->previous()); ?>"><  Volver</button>
        </div>
        <!-- Fin Botón "volver" -->

        <!-- Inicio Información del ticket regalo -->
        <div id="codigoRegalo">
            <h1>¡Gracias por cuidarnos!</h1>
            <p>Para poder retirar <span id="ingresarRegalo">{regalo}</span> presentá el siguiente código en el comercio</p>
            <div id="ticket">
                <p><?php echo e($otp->otp_pass); ?></p>
                <img src=<?php echo e(asset('assets/ticketConfirmacion.svg')); ?>>
                
            </div>
        </div>
        <!-- Fin Información del ticket regalo -->

        <!-- Inicio Calificar comercio -->
        <div>
            <img src="<?php echo e(asset('assets/like.svg')); ?>" alt="like" id="dibujoLike">  
            <div id="calificar">
                <h2>Calificá tu experiencia</h2>
            
            <ul class="row justify-content-center">
                <li><form action="<?php echo e(route('puntuacion', 1)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" id="estrella1" onclick="getRating(this.id)"><img src="<?php echo e(asset('assets/estrella.svg')); ?>" alt=""></button>
                </form></li>
                <li><form action="<?php echo e(route('puntuacion', 2)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" id="estrella1" onclick="getRating(this.id)"><img src="<?php echo e(asset('assets/estrella.svg')); ?>" alt=""></button>
                </form></li>
                <li><form action="<?php echo e(route('puntuacion', 3)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" id="estrella1" onclick="getRating(this.id)"><img src="<?php echo e(asset('assets/estrella.svg')); ?>" alt=""></button>
                </form></li>
                <li><form action="<?php echo e(route('puntuacion', 4)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" id="estrella1" onclick="getRating(this.id)"><img src="<?php echo e(asset('assets/estrella.svg')); ?>" alt=""></button>
                </form></li>
                <li><form action="<?php echo e(route('puntuacion', 5)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" id="estrella1" onclick="getRating(this.id)"><img src="<?php echo e(asset('assets/estrella.svg')); ?>" alt=""></button>
                </form></li>
            </ul>
               
                <h3>Nombre de comercio</h3>
                <p><img src="<?php echo e(asset('assets/gota.svg')); ?>" alt="ubicacion">Av. Defensa 700, Buenos Aires</p>
            </div>
        </div> 
        <!-- Fin Calificar comercio -->
    </div>
    <!-- Fin contenedor -->
    <script>
        function getRating(rating){
            let token = document.querySelector(‘meta[name=”csrftoken”]’).getAttribute(‘content’);
            rating = parseInt(rating[8],10);
            console.log(rating);
            let url = '/puntuacion';
            let redirect = '/';
            fetch(url, {
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json, text-plain, */*",
                    "X-Requested-With": "XMLHttpRequest",
                    "X-CSRF-TOKEN": token
                    },
                method: 'post',
                credentials: "same-origin",
                body: JSON.stringify({
                    rating: rating,
                })
                })
                .then((data) => {
                    form.reset();
                    window.location.href = redirect;
                })
                .catch(function(error) {
                    console.log(error);
                    });
                }
            
            /* const token = document.querySelector('meta[name="csrf-token"]').content;
            url = '/puntuacion';

            fetch(url,{
                method: 'POST',
                credentials: 'omit',
                mode: 'same-origin',
                headers:{
                    "Content-Type": "application/json; charset=utf-8",
                    "X-CSRF-TOKEN": token
                },
                body: JSON.stringify({puntuacion: rating})
            }); */
        }
    </script>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nicolas/Programacion/ProyectoContraCoronavirus/te-lo-regalo/resources/views/otps/buy.blade.php ENDPATH**/ ?>